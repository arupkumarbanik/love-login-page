export type VerificationStatus = 'idle' | 'verifying' | 'success' | 'unsuccessful' | 'incomplete';

export interface OtpVerificationResult {
  success: boolean;
  message: string;
  timestamp?: number;
}

export interface ToastNotification {
  id: string;
  type: 'info' | 'success' | 'error';
  message: string;
}
