/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ParticleBackground } from './components/ParticleBackground';
import { WeddingIcon } from './components/WeddingIcon';
import { OtpInput } from './components/OtpInput';
import { SuccessView } from './components/SuccessView';
import { BrokenHeartView } from './components/BrokenHeartView';
import { Toast } from './components/Toast';
import { VerificationStatus, ToastNotification } from './types';
import { verifyOtpCode, requestResendOtp, DEMO_CORRECT_OTP } from './utils/otpValidator';
import { ArrowRight, Loader2, Sparkles, RefreshCw, HeartHandshake } from 'lucide-react';

export default function App() {
  const [otp, setOtp] = useState<string[]>(['', '', '', '', '', '']);
  const [status, setStatus] = useState<VerificationStatus>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [toast, setToast] = useState<ToastNotification | null>(null);
  const [resendCountdown, setResendCountdown] = useState<number>(30);
  const [isResending, setIsResending] = useState<boolean>(false);

  // Resend countdown timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (resendCountdown > 0) {
      timer = setInterval(() => {
        setResendCountdown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [resendCountdown]);

  const showToast = (message: string, type: 'info' | 'success' | 'error' = 'info') => {
    setToast({
      id: Math.random().toString(),
      type,
      message,
    });
    setTimeout(() => {
      setToast(null);
    }, 4500);
  };

  const handleOtpChange = (newOtp: string[]) => {
    setOtp(newOtp);
    if (errorMessage) {
      setErrorMessage('');
    }
    if (status === 'incomplete') {
      setStatus('idle');
    }
  };

  const handleVerify = async () => {
    const fullOtp = otp.join('');

    // Check if fewer than 6 digits
    if (fullOtp.length < 6) {
      setStatus('incomplete');
      setErrorMessage('Please enter the complete 6-digit OTP.');
      showToast('Please enter the complete 6-digit OTP.', 'error');
      return;
    }

    setStatus('verifying');
    setErrorMessage('');

    try {
      // Call modular verification logic (easily swappable with backend API)
      const result = await verifyOtpCode(fullOtp);

      if (result.success) {
        setStatus('success');
      } else {
        setStatus('unsuccessful');
      }
    } catch {
      setStatus('unsuccessful');
      setErrorMessage('Verification failed due to a network error. Please try again.');
    }
  };

  const handleResend = async () => {
    if (resendCountdown > 0 || isResending) return;

    setIsResending(true);
    try {
      const res = await requestResendOtp();
      showToast(res.message, 'success');
      setResendCountdown(30);
      setOtp(['', '', '', '', '', '']);
      setErrorMessage('');
      setStatus('idle');
    } catch {
      showToast('Unable to resend OTP at this time. Please try again later.', 'error');
    } finally {
      setIsResending(false);
    }
  };

  const handleResetToForm = () => {
    setOtp(['', '', '', '', '', '']);
    setStatus('idle');
    setErrorMessage('');
  };

  const handleQuickFill = (code: string) => {
    const digits = code.split('').slice(0, 6);
    const newOtp = ['', '', '', '', '', ''];
    for (let i = 0; i < digits.length; i++) {
      newOtp[i] = digits[i];
    }
    setOtp(newOtp);
    setErrorMessage('');
    setStatus('idle');
  };

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center p-4 sm:p-6 select-none font-sans-main">
      {/* Dynamic ambient particle background with glowing hearts and sparkles */}
      <ParticleBackground />

      {/* Floating Toast Notification */}
      <Toast toast={toast} onDismiss={() => setToast(null)} />

      {/* Header Accent Bar */}
      <header className="relative z-10 mb-3 text-center">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full wedding-glass-subtle text-xs tracking-wider uppercase font-semibold text-rose-800 shadow-sm border border-rose-200/60">
          <HeartHandshake className="w-3.5 h-3.5 text-rose-600" />
          <span>Royal Wedding Portal</span>
        </div>
      </header>

      {/* Main Glassmorphism OTP Verification Card */}
      <main className="relative z-10 w-full max-w-[460px] wedding-glass-card rounded-3xl p-6 sm:p-8 shadow-2xl transition-all duration-300">
        
        {/* Subtle Decorative Golden Border Inner Ring */}
        <div className="absolute inset-2 pointer-events-none rounded-[22px] border border-rose-200/50" />

        {/* Dynamic Card Body based on Status */}
        {status === 'success' ? (
          <SuccessView onReset={handleResetToForm} />
        ) : status === 'unsuccessful' ? (
          <BrokenHeartView onRetry={handleResetToForm} />
        ) : (
          <div className="flex flex-col items-center text-center">
            
            {/* Top Romantic Wedding Icon */}
            <div className="mb-4">
              <WeddingIcon size="md" />
            </div>

            {/* Page Title */}
            <h1
              id="verification-title"
              className="text-2xl sm:text-3xl font-bold font-playfair tracking-tight text-rose-950 mb-2"
            >
              Verify Your Love
            </h1>

            {/* Subtitle */}
            <p className="text-stone-600 text-xs sm:text-sm font-sans-main max-w-xs leading-relaxed mb-5">
              Enter the 6-digit verification code sent to your registered mobile number{' '}
              <span className="font-semibold text-stone-800 whitespace-nowrap">+91 ••••• ••482</span>
            </p>

            {/* Incomplete Error Inline Banner */}
            {errorMessage && (
              <div
                id="error-banner"
                className="w-full bg-rose-50 border border-rose-300/80 rounded-xl py-2 px-3 mb-3 text-xs text-rose-800 font-medium animate-in fade-in"
              >
                {errorMessage}
              </div>
            )}

            {/* 6 OTP Input Boxes */}
            <OtpInput
              value={otp}
              onChange={handleOtpChange}
              disabled={status === 'verifying'}
              hasError={Boolean(errorMessage) || status === 'incomplete'}
              onEnterPress={handleVerify}
            />

            {/* Large Premium "Verify OTP" Button */}
            <button
              id="btn-verify-otp"
              type="button"
              disabled={status === 'verifying'}
              onClick={handleVerify}
              className="w-full mt-3 py-3.5 sm:py-4 px-6 rounded-2xl bg-gradient-to-r from-rose-500 via-pink-600 to-rose-600 text-white font-semibold text-sm sm:text-base tracking-wide shadow-lg shadow-rose-300/40 hover:shadow-rose-400/60 hover:from-rose-600 hover:to-pink-700 active:scale-[0.99] transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed group"
            >
              {status === 'verifying' ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin text-white" />
                  <span>Verifying Code...</span>
                </>
              ) : (
                <>
                  <span>Verify OTP</span>
                  <ArrowRight className="w-4 h-4 text-rose-100 group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>

            {/* Resend OTP Section */}
            <div className="mt-5 text-xs text-stone-600 flex flex-col items-center gap-1.5">
              <div className="flex items-center gap-1.5 flex-wrap justify-center">
                <span>Didn&apos;t receive the code?</span>
                <button
                  id="btn-resend-otp"
                  type="button"
                  disabled={resendCountdown > 0 || isResending || status === 'verifying'}
                  onClick={handleResend}
                  className={`font-semibold transition-colors flex items-center gap-1 ${
                    resendCountdown > 0 || isResending
                      ? 'text-stone-400 cursor-not-allowed'
                      : 'text-rose-600 hover:text-rose-800 underline underline-offset-2 cursor-pointer'
                  }`}
                >
                  {isResending ? (
                    <>
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      <span>Sending...</span>
                    </>
                  ) : (
                    <span>
                      Resend OTP {resendCountdown > 0 ? `(${resendCountdown}s)` : ''}
                    </span>
                  )}
                </button>
              </div>

              {/* Demo Helper Shortcuts */}
              <div className="mt-4 pt-3 border-t border-rose-100/80 w-full flex items-center justify-between text-[11px] text-stone-500">
                <span className="flex items-center gap-1 text-stone-400">
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  Demo Shortcuts:
                </span>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => handleQuickFill(DEMO_CORRECT_OTP)}
                    className="px-2 py-0.5 rounded-md bg-rose-100/70 hover:bg-rose-200 text-rose-800 font-medium transition-colors"
                    title="Fill 123456"
                  >
                    123456 (Valid)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickFill('987654')}
                    className="px-2 py-0.5 rounded-md bg-stone-100 hover:bg-stone-200 text-stone-700 font-medium transition-colors"
                    title="Fill invalid code"
                  >
                    Invalid OTP
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer Branding Note */}
      <footer className="relative z-10 mt-6 text-center text-xs text-rose-800/70 flex items-center justify-center gap-1.5">
        <span>Crafted with love for wedding guest verification</span>
        <span>•</span>
        <span>Encrypted &amp; Secure</span>
      </footer>
    </div>
  );
}
