import { OtpVerificationResult } from '../types';

/**
 * Demo OTP configuration
 * In a real production application, this constant would not exist client-side
 * and validation would happen on the server via `verifyOtpWithBackend()`.
 */
export const DEMO_CORRECT_OTP = '123456';

/**
 * Modular verification function.
 * Replace this implementation with an actual API endpoint when deploying to production:
 * 
 * Example:
 * ```ts
 * export async function verifyOtpCode(otp: string): Promise<OtpVerificationResult> {
 *   const response = await fetch('/api/verify-otp', {
 *     method: 'POST',
 *     headers: { 'Content-Type': 'application/json' },
 *     body: JSON.stringify({ otp }),
 *   });
 *   return await response.json();
 * }
 * ```
 */
export async function verifyOtpCode(otp: string): Promise<OtpVerificationResult> {
  // Simulate minimal realistic network verification latency (350ms)
  await new Promise((resolve) => setTimeout(resolve, 350));

  if (!otp || otp.length !== 6 || !/^\d{6}$/.test(otp)) {
    return {
      success: false,
      message: 'Please enter the complete 6-digit OTP.',
      timestamp: Date.now(),
    };
  }

  if (otp === DEMO_CORRECT_OTP) {
    return {
      success: true,
      message: 'Verification Successful',
      timestamp: Date.now(),
    };
  }

  return {
    success: false,
    message: 'Verification Unsuccessful',
    timestamp: Date.now(),
  };
}

/**
 * Service to request a new OTP code
 */
export async function requestResendOtp(mobileNumber?: string): Promise<{ success: boolean; message: string }> {
  // Simulate network dispatch
  await new Promise((resolve) => setTimeout(resolve, 300));
  return {
    success: true,
    message: 'A new 6-digit verification code has been sent to your registered mobile number.',
  };
}
