import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  opacity: number;
  type: 'heart' | 'sparkle' | 'orb';
  rotation: number;
  rotationSpeed: number;
  hue: number;
}

export const ParticleBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    const particles: Particle[] = [];
    const particleCount = Math.min(width < 768 ? 24 : 45, 50);

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 12 + 6,
        speedY: -(Math.random() * 0.45 + 0.15),
        speedX: (Math.random() - 0.5) * 0.3,
        opacity: Math.random() * 0.5 + 0.2,
        type: Math.random() > 0.45 ? 'heart' : Math.random() > 0.5 ? 'sparkle' : 'orb',
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 0.8,
        hue: Math.random() > 0.3 ? 340 + Math.random() * 20 : 42, // Rose pinks or warm gold
      });
    }

    const drawHeart = (
      c: CanvasRenderingContext2D,
      x: number,
      y: number,
      size: number,
      opacity: number,
      rotation: number,
      hue: number
    ) => {
      c.save();
      c.translate(x, y);
      c.rotate((rotation * Math.PI) / 180);
      c.beginPath();
      const topCurveHeight = size * 0.3;
      c.moveTo(0, topCurveHeight);
      // top left curve
      c.bezierCurveTo(
        -size / 2,
        -size / 2,
        -size,
        topCurveHeight / 3,
        0,
        size
      );
      // top right curve
      c.bezierCurveTo(
        size,
        topCurveHeight / 3,
        size / 2,
        -size / 2,
        0,
        topCurveHeight
      );
      c.closePath();

      if (hue < 100) {
        c.fillStyle = `rgba(245, 208, 120, ${opacity * 0.65})`;
      } else {
        c.fillStyle = `rgba(251, 140, 180, ${opacity * 0.7})`;
      }
      c.fill();
      c.restore();
    };

    const drawSparkle = (
      c: CanvasRenderingContext2D,
      x: number,
      y: number,
      size: number,
      opacity: number
    ) => {
      c.save();
      c.translate(x, y);
      c.beginPath();
      for (let i = 0; i < 4; i++) {
        c.lineTo(Math.cos(((i * 90) * Math.PI) / 180) * size, Math.sin(((i * 90) * Math.PI) / 180) * size);
        c.lineTo(
          Math.cos(((i * 90 + 45) * Math.PI) / 180) * (size * 0.3),
          Math.sin(((i * 90 + 45) * Math.PI) / 180) * (size * 0.3)
        );
      }
      c.closePath();
      c.fillStyle = `rgba(254, 240, 138, ${opacity * 0.85})`;
      c.shadowBlur = 8;
      c.shadowColor = 'rgba(251, 191, 36, 0.6)';
      c.fill();
      c.restore();
    };

    const drawOrb = (
      c: CanvasRenderingContext2D,
      x: number,
      y: number,
      size: number,
      opacity: number,
      hue: number
    ) => {
      c.save();
      c.beginPath();
      c.arc(x, y, size * 0.6, 0, Math.PI * 2);
      const gradient = c.createRadialGradient(x, y, 0, x, y, size * 0.8);
      gradient.addColorStop(0, `hsla(${hue}, 85%, 80%, ${opacity})`);
      gradient.addColorStop(1, `hsla(${hue}, 85%, 80%, 0)`);
      c.fillStyle = gradient;
      c.fill();
      c.restore();
    };

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      particles.forEach((p) => {
        p.y += p.speedY;
        p.x += p.speedX + Math.sin(p.y * 0.005) * 0.2;
        p.rotation += p.rotationSpeed;

        if (p.y < -30) {
          p.y = height + 20;
          p.x = Math.random() * width;
        }
        if (p.x < -20) p.x = width + 10;
        if (p.x > width + 20) p.x = -10;

        if (p.type === 'heart') {
          drawHeart(ctx, p.x, p.y, p.size, p.opacity, p.rotation, p.hue);
        } else if (p.type === 'sparkle') {
          drawSparkle(ctx, p.x, p.y, p.size * 0.8, p.opacity);
        } else {
          drawOrb(ctx, p.x, p.y, p.size, p.opacity, p.hue);
        }
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {/* Soft romantic ambient mesh gradient */}
      <div className="absolute inset-0 bg-radial-[at_top_center] from-[#ffe5ee] via-[#fff1f5] to-[#fce7f3] opacity-90" />
      
      {/* Subtle Indian wedding gold and rose ambient glow circles */}
      <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-rose-200/40 blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 -right-32 w-96 h-96 rounded-full bg-pink-300/30 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 left-1/4 w-[30rem] h-[30rem] rounded-full bg-amber-100/40 blur-3xl pointer-events-none" />
      
      {/* Delicate ornamental floral/mandala corner silhouettes */}
      <div className="absolute top-0 left-0 w-44 h-44 opacity-15 text-rose-400 pointer-events-none transform -rotate-12">
        <svg viewBox="0 0 100 100" fill="currentColor">
          <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2 3" />
          <path d="M50 5 C55 25 75 45 95 50 C75 55 55 75 50 95 C45 75 25 55 5 50 C25 45 45 25 50 5 Z" fill="none" stroke="currentColor" strokeWidth="0.75" />
          <circle cx="50" cy="50" r="15" fill="none" stroke="currentColor" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="absolute bottom-0 right-0 w-44 h-44 opacity-15 text-rose-400 pointer-events-none transform rotate-180">
        <svg viewBox="0 0 100 100" fill="currentColor">
          <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2 3" />
          <path d="M50 5 C55 25 75 45 95 50 C75 55 55 75 50 95 C45 75 25 55 5 50 C25 45 45 25 50 5 Z" fill="none" stroke="currentColor" strokeWidth="0.75" />
          <circle cx="50" cy="50" r="15" fill="none" stroke="currentColor" strokeWidth="0.5" />
        </svg>
      </div>

      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
    </div>
  );
};
