import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { ToastNotification } from '../types';

interface ToastProps {
  toast: ToastNotification | null;
  onDismiss: () => void;
}

export const Toast: React.FC<ToastProps> = ({ toast, onDismiss }) => {
  if (!toast) return null;

  const bgStyles = {
    success: 'bg-rose-900/90 text-white border-rose-700 shadow-rose-200/50',
    error: 'bg-red-900/90 text-white border-red-700 shadow-red-200/50',
    info: 'bg-stone-900/90 text-white border-stone-700 shadow-stone-200/50',
  }[toast.type];

  const Icon = {
    success: CheckCircle2,
    error: AlertCircle,
    info: Info,
  }[toast.type];

  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 max-w-md w-[90%] px-4 animate-in fade-in slide-in-from-top-4 duration-300 pointer-events-auto">
      <div
        className={`flex items-center justify-between gap-3 px-4 py-3 rounded-2xl border backdrop-blur-md shadow-xl text-sm ${bgStyles}`}
      >
        <div className="flex items-center gap-2.5">
          <Icon className="w-4 h-4 shrink-0 text-rose-300" />
          <span className="font-sans-main font-medium leading-tight">{toast.message}</span>
        </div>
        <button
          type="button"
          onClick={onDismiss}
          className="p-1 text-white/70 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
          aria-label="Close notification"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
