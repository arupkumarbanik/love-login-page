import React from 'react';
import { CheckCircle2, Sparkles, RotateCcw } from 'lucide-react';

interface SuccessViewProps {
  onReset: () => void;
}

export const SuccessView: React.FC<SuccessViewProps> = ({ onReset }) => {
  // Define 8 floating micro hearts with radial trajectories
  const microHearts = [
    { tx: '-45px', ty: '-65px', rot: '-25deg', delay: '0s', size: '14px' },
    { tx: '45px', ty: '-60px', rot: '20deg', delay: '0.3s', size: '16px' },
    { tx: '-60px', ty: '-15px', rot: '-35deg', delay: '0.6s', size: '12px' },
    { tx: '65px', ty: '-10px', rot: '30deg', delay: '0.9s', size: '15px' },
    { tx: '-40px', ty: '35px', rot: '-15deg', delay: '1.2s', size: '13px' },
    { tx: '45px', ty: '30px', rot: '25deg', delay: '0.4s', size: '14px' },
    { tx: '0px', ty: '-75px', rot: '5deg', delay: '0.7s', size: '18px' },
    { tx: '0px', ty: '45px', rot: '-10deg', delay: '1.5s', size: '12px' },
  ];

  return (
    <div className="flex flex-col items-center justify-center text-center py-4 px-2">
      {/* Central Heartbeat & Floating Outward Hearts Area */}
      <div className="relative w-36 h-36 flex items-center justify-center my-3">
        {/* Outward Floating Small Hearts */}
        {microHearts.map((heart, idx) => (
          <div
            key={idx}
            className="absolute pointer-events-none text-rose-400 select-none animate-float-outward z-0"
            style={
              {
                '--tx': heart.tx,
                '--ty': heart.ty,
                '--rot': heart.rot,
                animationDelay: heart.delay,
                fontSize: heart.size,
              } as React.CSSProperties
            }
          >
            ❤
          </div>
        ))}

        {/* Ambient Soft Gold/Rose Glow */}
        <div className="absolute inset-2 rounded-full bg-gradient-to-tr from-rose-400/30 via-pink-500/20 to-amber-300/30 blur-xl animate-pulse" />

        {/* Main Radiant Animated Heart with Rhythmic Heartbeat */}
        <div className="relative z-10 animate-heartbeat flex items-center justify-center filter drop-shadow-[0_10px_20px_rgba(225,29,72,0.35)]">
          <svg
            viewBox="0 0 100 100"
            className="w-24 h-24 sm:w-28 sm:h-28"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <radialGradient id="heartBodyGrad" cx="35%" cy="30%" r="70%">
                <stop offset="0%" stopColor="#ff4d79" />
                <stop offset="45%" stopColor="#e11d48" />
                <stop offset="85%" stopColor="#be123c" />
                <stop offset="100%" stopColor="#881337" />
              </radialGradient>
              <linearGradient id="heartGloss" x1="0%" y1="0%" x2="50%" y2="100%">
                <stop offset="0%" stopColor="#ffffff" stopOpacity="0.6" />
                <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Sculpted Heart Shape */}
            <path
              d="M50 88.5 C20 68 5 48 5 28 C5 14 16 4 30 4 C39 4 46 9 50 16 C54 9 61 4 70 4 C84 4 95 14 95 28 C95 48 80 68 50 88.5 Z"
              fill="url(#heartBodyGrad)"
              stroke="#ffe4e6"
              strokeWidth="1.5"
            />

            {/* Gloss Highlight on Left Chamber */}
            <path
              d="M30 9 C20 9 12 17 12 28 C12 37 19 49 32 60 C26 50 20 38 20 28 C20 18 25 12 32 10 C31 9.5 30.5 9 30 9 Z"
              fill="url(#heartGloss)"
            />

            {/* Sparkle Glint */}
            <polygon
              points="70,16 73,22 79,23 74,27 76,33 70,29 64,33 66,27 61,23 67,22"
              fill="#ffffff"
              opacity="0.8"
            />
          </svg>

          {/* Central subtle checkmark overlay */}
          <div className="absolute inset-0 flex items-center justify-center text-white/90">
            <CheckCircle2 className="w-8 h-8 text-white drop-shadow-md" strokeWidth={2.5} />
          </div>
        </div>
      </div>

      {/* Success Title with Playfair Font */}
      <h3 className="text-2xl sm:text-3xl font-bold font-playfair text-rose-900 mb-1 flex items-center justify-center gap-2">
        <Sparkles className="w-5 h-5 text-amber-500 animate-spin" style={{ animationDuration: '6s' }} />
        <span>Verification Successful</span>
        <Sparkles className="w-5 h-5 text-amber-500 animate-spin" style={{ animationDuration: '6s' }} />
      </h3>

      <p className="text-stone-600 font-sans-main text-sm sm:text-base max-w-xs sm:max-w-sm mb-6 leading-relaxed">
        Your love has been verified! Welcome to the sacred celebration of together forever.
      </p>

      {/* Decorative Wedding Card Token */}
      <div className="w-full bg-rose-50/90 rounded-2xl p-4 border border-rose-200/80 mb-6 shadow-sm flex flex-col items-center justify-center">
        <div className="text-xs uppercase tracking-widest font-semibold text-rose-700 mb-1">
          Wedding Passcode Confirmed
        </div>
        <div className="text-lg font-playfair font-semibold text-rose-950">
          Aarav &amp; Ananya&apos;s Wedding
        </div>
        <div className="text-xs text-stone-500 mt-1">
          November 28, 2026 • Royal Palace, Udaipur
        </div>
      </div>

      {/* Reset / Test Again Button */}
      <button
        id="btn-success-reset"
        type="button"
        onClick={onReset}
        className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-rose-500 via-pink-600 to-rose-600 text-white font-medium shadow-md shadow-rose-200 hover:from-rose-600 hover:to-pink-700 transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-sm"
      >
        <RotateCcw className="w-4 h-4" />
        <span>Test Another Code</span>
      </button>
    </div>
  );
};
