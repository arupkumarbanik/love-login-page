import React from 'react';
import { AlertCircle, RotateCcw } from 'lucide-react';

interface BrokenHeartViewProps {
  onRetry: () => void;
}

export const BrokenHeartView: React.FC<BrokenHeartViewProps> = ({ onRetry }) => {
  return (
    <div className="flex flex-col items-center justify-center text-center py-4 px-2">
      {/* Broken Heart Animation Area */}
      <div className="relative w-36 h-36 flex items-center justify-center my-3">
        {/* Ambient Muted Glow */}
        <div className="absolute inset-2 rounded-full bg-rose-900/10 blur-xl" />

        {/* Floating falling shards/teardrops */}
        <div className="absolute top-16 left-10 w-1.5 h-3 rounded-full bg-rose-300/80 animate-bounce" style={{ animationDuration: '2.5s' }} />
        <div className="absolute top-20 right-10 w-1.5 h-2.5 rounded-full bg-rose-300/80 animate-bounce" style={{ animationDuration: '3s', animationDelay: '0.5s' }} />

        {/* Broken Heart SVG with Fracturing Halves */}
        <div className="relative z-10 w-28 h-28 flex items-center justify-center filter drop-shadow-[0_8px_16px_rgba(159,18,57,0.25)] animate-broken-tremor">
          <svg
            viewBox="0 0 100 100"
            className="w-24 h-24 sm:w-28 sm:h-28 overflow-visible"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="brokenHeartLeftGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#f43f5e" />
                <stop offset="70%" stopColor="#9f1239" />
                <stop offset="100%" stopColor="#4c0519" />
              </linearGradient>
              <linearGradient id="brokenHeartRightGrad" x1="100%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#fb7185" />
                <stop offset="70%" stopColor="#be123c" />
                <stop offset="100%" stopColor="#4c0519" />
              </linearGradient>
            </defs>

            {/* Left Half (Fractured Edge) */}
            <g className="animate-split-left origin-bottom">
              <path
                d="M50 16 C46 9 39 4 30 4 C16 4 5 14 5 28 C5 48 20 68 50 88.5 L50 88.5 L46 72 L54 58 L45 44 L55 30 L47 22 L50 16 Z"
                fill="url(#brokenHeartLeftGrad)"
                stroke="#ffe4e6"
                strokeWidth="1.2"
              />
            </g>

            {/* Right Half (Fractured Edge) */}
            <g className="animate-split-right origin-bottom">
              <path
                d="M50 16 C54 9 61 4 70 4 C84 4 95 14 95 28 C95 48 80 68 50 88.5 L50 88.5 L46 72 L54 58 L45 44 L55 30 L47 22 L50 16 Z"
                fill="url(#brokenHeartRightGrad)"
                stroke="#ffe4e6"
                strokeWidth="1.2"
              />
            </g>

            {/* Glowing Crack Line Flash */}
            <path
              d="M50 16 L47 22 L55 30 L45 44 L54 58 L46 72 L50 88.5"
              stroke="#ffffff"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="animate-crack-flash"
            />
          </svg>
        </div>
      </div>

      {/* Unsuccessful Title */}
      <h3 className="text-2xl sm:text-3xl font-bold font-playfair text-rose-950 mb-1 flex items-center justify-center gap-2">
        <AlertCircle className="w-5 h-5 text-rose-600" />
        <span>Verification Unsuccessful</span>
      </h3>

      <p className="text-stone-600 font-sans-main text-sm sm:text-base max-w-xs sm:max-w-sm mb-6 leading-relaxed">
        The 6-digit code does not match our records. Please double-check your code or request a new one.
      </p>

      {/* Demo Hint Box */}
      <div className="w-full bg-amber-50/80 rounded-2xl p-3.5 border border-amber-200/80 mb-6 text-xs text-amber-900 flex items-center gap-2.5 text-left">
        <span className="text-base">💡</span>
        <div>
          <span className="font-semibold">Demo Hint:</span> Use <strong>123456</strong> to verify successfully.
        </div>
      </div>

      {/* Try Again Button */}
      <button
        id="btn-error-retry"
        type="button"
        onClick={onRetry}
        className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-stone-900 text-white font-medium shadow-md hover:bg-stone-800 transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-sm"
      >
        <RotateCcw className="w-4 h-4" />
        <span>Try Again</span>
      </button>
    </div>
  );
};
