import React from 'react';

export const WeddingIcon: React.FC<{ size?: 'sm' | 'md' | 'lg' }> = ({ size = 'md' }) => {
  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-20 h-20',
    lg: 'w-24 h-24',
  }[size];

  return (
    <div className="relative flex items-center justify-center">
      {/* Outer soft glow ring */}
      <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-rose-300/40 via-pink-400/25 to-amber-300/30 blur-md animate-pulse" />
      
      {/* Container with delicate glass badge */}
      <div className={`relative ${sizeClasses} rounded-full bg-gradient-to-b from-white/90 to-rose-50/90 border border-rose-200/90 shadow-sm flex items-center justify-center p-3.5`}>
        {/* Custom SVG Wedding Ring and Heart Motif */}
        <svg
          viewBox="0 0 64 64"
          className="w-full h-full text-rose-600 drop-shadow-sm"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="goldRingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#eab308" />
              <stop offset="50%" stopColor="#fbbf24" />
              <stop offset="100%" stopColor="#d97706" />
            </linearGradient>
            <linearGradient id="roseHeartGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f43f5e" />
              <stop offset="100%" stopColor="#be123c" />
            </linearGradient>
            <linearGradient id="diamondGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="50%" stopColor="#e0f2fe" />
              <stop offset="100%" stopColor="#93c5fd" />
            </linearGradient>
          </defs>

          {/* Left Ring (Intertwined) */}
          <ellipse
            cx="24"
            cy="36"
            rx="14"
            ry="14"
            stroke="url(#goldRingGrad)"
            strokeWidth="3.2"
            strokeLinecap="round"
          />

          {/* Right Ring (Intertwined) */}
          <ellipse
            cx="40"
            cy="36"
            rx="14"
            ry="14"
            stroke="url(#goldRingGrad)"
            strokeWidth="3.2"
            strokeLinecap="round"
          />

          {/* Central Connecting Radiant Heart */}
          <path
            d="M32 20C29.5 16 23 16 23 21C23 26 32 32 32 32C32 32 41 26 41 21C41 16 34.5 16 32 20Z"
            fill="url(#roseHeartGrad)"
            stroke="#ffffff"
            strokeWidth="1"
          />

          {/* Solitaire Diamond on Top */}
          <polygon
            points="32,7 36,12 32,16 28,12"
            fill="url(#diamondGrad)"
            stroke="#fbbf24"
            strokeWidth="0.8"
          />
          {/* Diamond sparkles */}
          <circle cx="32" cy="7" r="1.5" fill="#ffffff" />
          <line x1="32" y1="3" x2="32" y2="5" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round" />
          <line x1="27" y1="7" x2="29" y2="7" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round" />
          <line x1="35" y1="7" x2="37" y2="7" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round" />
        </svg>

        {/* Floating tiny heart accent badge */}
        <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[10px] text-white shadow">
          ❤
        </span>
      </div>
    </div>
  );
};
