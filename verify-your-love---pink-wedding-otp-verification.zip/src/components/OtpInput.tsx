import React, { useRef, useEffect } from 'react';

interface OtpInputProps {
  value: string[];
  onChange: (otp: string[]) => void;
  disabled?: boolean;
  hasError?: boolean;
  onEnterPress?: () => void;
}

export const OtpInput: React.FC<OtpInputProps> = ({
  value,
  onChange,
  disabled = false,
  hasError = false,
  onEnterPress,
}) => {
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Initialize refs array
  useEffect(() => {
    inputRefs.current = inputRefs.current.slice(0, 6);
  }, []);

  const handleChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value;
    // Accept numbers only
    const digitsOnly = rawVal.replace(/\D/g, '');

    if (!digitsOnly) {
      const newOtp = [...value];
      newOtp[index] = '';
      onChange(newOtp);
      return;
    }

    // If a single character was typed
    const singleDigit = digitsOnly[digitsOnly.length - 1];
    const newOtp = [...value];
    newOtp[index] = singleDigit;
    onChange(newOtp);

    // Auto-focus next box
    if (index < 5) {
      inputRefs.current[index + 1]?.focus();
      inputRefs.current[index + 1]?.select();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!value[index] && index > 0) {
        // Current box is empty, focus previous box and delete its content
        e.preventDefault();
        const newOtp = [...value];
        newOtp[index - 1] = '';
        onChange(newOtp);
        inputRefs.current[index - 1]?.focus();
      } else if (value[index]) {
        // Current box has value, clear it without jumping back immediately
        const newOtp = [...value];
        newOtp[index] = '';
        onChange(newOtp);
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      e.preventDefault();
      inputRefs.current[index - 1]?.focus();
      inputRefs.current[index - 1]?.select();
    } else if (e.key === 'ArrowRight' && index < 5) {
      e.preventDefault();
      inputRefs.current[index + 1]?.focus();
      inputRefs.current[index + 1]?.select();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (onEnterPress) {
        onEnterPress();
      }
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text/plain');
    // Extract only digits
    const digits = pastedData.replace(/\D/g, '').slice(0, 6);

    if (!digits) return;

    const newOtp = ['', '', '', '', '', ''];
    for (let i = 0; i < digits.length; i++) {
      newOtp[i] = digits[i];
    }
    onChange(newOtp);

    // Focus the box after the last pasted digit or the 6th box
    const focusIndex = Math.min(digits.length, 5);
    inputRefs.current[focusIndex]?.focus();
    inputRefs.current[focusIndex]?.select();
  };

  const handleFocus = (index: number) => {
    inputRefs.current[index]?.select();
  };

  return (
    <div className="w-full">
      <div className={`flex justify-center items-center gap-2 sm:gap-3 my-4 ${hasError ? 'animate-error-shake' : ''}`}>
        {Array.from({ length: 6 }).map((_, index) => {
          const isFilled = Boolean(value[index]);
          return (
            <div key={index} className="relative group">
              <input
                ref={(el) => {
                  inputRefs.current[index] = el;
                }}
                id={`otp-digit-${index}`}
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={1}
                value={value[index] || ''}
                disabled={disabled}
                onChange={(e) => handleChange(index, e)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onPaste={handlePaste}
                onFocus={() => handleFocus(index)}
                autoComplete="one-time-code"
                aria-label={`Digit ${index + 1} of 6-digit OTP`}
                className={`
                  w-11 h-14 sm:w-13 sm:h-16 text-center text-xl sm:text-2xl font-semibold rounded-xl
                  transition-all duration-200 ease-out outline-none
                  font-sans-main select-all
                  ${
                    disabled
                      ? 'bg-rose-50/50 text-stone-400 border-rose-100 cursor-not-allowed'
                      : hasError
                      ? 'bg-rose-50 text-rose-800 border-2 border-rose-500 shadow-[0_0_12px_rgba(244,63,94,0.3)]'
                      : isFilled
                      ? 'bg-white/95 text-rose-900 border-2 border-rose-400 shadow-[0_4px_12px_rgba(244,114,182,0.25)] ring-2 ring-rose-100'
                      : 'bg-white/70 text-stone-800 border border-rose-200/80 hover:border-rose-300 focus:bg-white focus:border-rose-500 focus:ring-4 focus:ring-rose-200/50 focus:shadow-[0_4px_16px_rgba(244,114,182,0.3)]'
                  }
                `}
              />
              {/* Subtle heart watermark in empty boxes on focus */}
              {!isFilled && !hasError && (
                <span className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-0 group-focus-within:opacity-15 text-rose-500 text-xs transition-opacity">
                  ❤
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
